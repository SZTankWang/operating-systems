#include "myfifo.h"

myfifo::myfifo(char * pathname,int flag){
	this->pathname = pathname;
	this->flag = flag;
};
